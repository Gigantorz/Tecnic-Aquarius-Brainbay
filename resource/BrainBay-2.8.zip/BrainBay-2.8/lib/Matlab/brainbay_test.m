% Brainbay test  
% sample function for BrainBay Matlab object
% 
% LR John, UCT, 2006
%
% This is a sample function to test the BrainBay Matlab object
% It adds two variables (A and B) and sends the result to Brainbay

function [Y] = brainbay_test(A,B)
Y = A+B;
return